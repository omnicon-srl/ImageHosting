Icone delle nazioni dei siti impianto
